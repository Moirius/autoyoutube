"""Everything about audio manipulation."""
